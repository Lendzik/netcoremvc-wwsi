﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Library.Models
{
    public class Book
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

        public Guid AuthorId { get; set; }
        public virtual Author? Author { get; set; }


        public string GetShortDescription()
        {
            return Description.Length > 60 ? Description.Substring(0, 60) + "..." : Description;
        }
    }
}
