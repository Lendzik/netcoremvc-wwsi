﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Library.Context;
using Library.Models;
using Library.Interfaces;
using Library.Migrations;

namespace Library.Controllers
{
    public class BooksController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public BooksController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _unitOfWork.Books.GetAll(b => b.Author));
        }

        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _unitOfWork.Books.GetById(id);
            var author = await _unitOfWork.Authors.GetById(book.AuthorId);
            book.Author = author;
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        public IActionResult Create()
        {

            var authors = _unitOfWork.Authors.GetAll().Result;
            var authorsSelectedList = new List<SelectListItem>();
            foreach(var author in authors)
            {
                authorsSelectedList.Add(new SelectListItem { Text = author.ToString(), Value = author.Id.ToString() });
            }

            ViewData["authors"] = authorsSelectedList;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Description,AuthorId")] Book book)
        {
            if (ModelState.IsValid)
            {
                book.Id = Guid.NewGuid();
                _unitOfWork.Books.Insert(book);
                await _unitOfWork.Books.Save();
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _unitOfWork.Books.GetById(id);
            if (book == null)
            {
                return NotFound();
            }

            var authors = _unitOfWork.Authors.GetAll().Result;
            var authorsSelectedList = new List<SelectListItem>();
            foreach (var author in authors)
            {
                authorsSelectedList.Add(new SelectListItem { Text = author.ToString(), Value = author.Id.ToString(), Selected = book.AuthorId == author.Id });
            }

            ViewData["authors"] = authorsSelectedList;


            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,Title,Description,AuthorId")] Book book)
        {
            if (id != book.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _unitOfWork.Books.Update(book);
                await _unitOfWork.Books.Save();

                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _unitOfWork.Books.GetById(id);
            var author = await _unitOfWork.Authors.GetById(book.AuthorId);
            book.Author = author;
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            _unitOfWork.Books.Delete(id);
            await _unitOfWork.Books.Save();
            return RedirectToAction(nameof(Index));
        }
    }
}
