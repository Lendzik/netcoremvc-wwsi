﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Library.Migrations
{
    public partial class Authors : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Authors",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uuid", nullable: false),
                    Name = table.Column<string>(type: "text", nullable: true),
                    Surname = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Authors", x => x.Id);
                });

            migrationBuilder.InsertData(

                table: "Authors",
                columns: new[] { "Id" ,"Name", "Surname" },
                values: new object[,]
    {
                    {Guid.NewGuid(), "Adam", "Mickiewicz" },
                    {Guid.NewGuid(),  "Henryk", "Sienkiewicz" },
                    {Guid.NewGuid(),   "Eliza", "Orzeszkowa" },
                    {Guid.NewGuid(),  "Władysław", "Reymont" },
                    {Guid.NewGuid(),  "Bolesław", "Prus" }
    });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Authors");
        }
    }
}
