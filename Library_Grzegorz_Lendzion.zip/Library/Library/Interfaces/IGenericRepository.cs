﻿using System.Linq.Expressions;

namespace Library.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        void Insert(T obj);
        Task<List<T>> GetAll(params Expression<Func<T, object>>[] includes);
        Task<T?> GetById(object id);
        void Update(T obj);
        void Delete(object id);
        Task Save();
    }
}
