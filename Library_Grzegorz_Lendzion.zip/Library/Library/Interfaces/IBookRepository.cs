﻿using Library.Models;

namespace Library.Interfaces
{
    public interface IBookRepository : IGenericRepository<Book>
    {
    }
}
