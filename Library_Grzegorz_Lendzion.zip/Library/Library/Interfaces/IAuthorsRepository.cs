﻿using Library.Models;

namespace Library.Interfaces
{
    public interface IAuthorRepository : IGenericRepository<Author>
    {
    }
}
