﻿using Library.Context;
using Library.Interfaces;
using Library.Models;

namespace Library.Repositories
{
    public class AuthorRepository : GenericRepository<Author>, IAuthorRepository
    {
        public AuthorRepository(AppDbContext context) : base(context)
        {
        }
    }
}
