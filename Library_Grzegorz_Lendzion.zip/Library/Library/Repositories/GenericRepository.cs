﻿using Library.Context;
using Library.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace Library.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {

        protected readonly AppDbContext _context;
        public GenericRepository(AppDbContext context)
        {
            _context = context;
        }

        public Task<List<T>> GetAll(params Expression<Func<T, object>>[] includes)
        {
            var query = _context.Set<T>().AsQueryable();
            if (includes != null)
            {
                foreach (var include in includes)
                {
                    query = query.Include(include);
                }
            }
            return query.ToListAsync();
        }

        public Task<T?> GetById(object id)
        {
            return _context.Set<T>().FindAsync(id).AsTask();
        }

        public void Insert(T obj)
        {
           _context.Set<T>().Add(obj);
        }

        public void Update(T obj)
        {
            _context.Set<T>().Update(obj);
        }

        public void Delete(object id)
        {
            var obj = GetById(id).Result;
            if(obj != null)
            {
                _context.Set<T>().Remove(obj);
            }

        }

        public Task Save()
        {
            return _context.SaveChangesAsync();
        }
    }
}
