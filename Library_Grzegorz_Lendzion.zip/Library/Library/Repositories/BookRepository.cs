﻿using Library.Context;
using Library.Interfaces;
using Library.Models;

namespace Library.Repositories
{
    public class BookRepository : GenericRepository<Book>, IBookRepository
    {
        public BookRepository(AppDbContext context) : base(context)
        {
        }
    }
}
