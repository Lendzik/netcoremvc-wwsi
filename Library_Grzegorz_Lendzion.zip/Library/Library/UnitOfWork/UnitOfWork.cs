﻿using Library.Context;
using Library.Interfaces;
using Library.Repositories;

namespace Library.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;
        public IAuthorRepository Authors { get; private set; }
        public IBookRepository Books { get; private set; }

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
            Authors = new AuthorRepository(context);
            Books = new BookRepository(context);
        }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
